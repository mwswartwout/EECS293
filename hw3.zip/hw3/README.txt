HW2 updated into HW3
To compile and run use the Ant build.xml file.