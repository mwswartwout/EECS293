package hw2;

/**
 * Marks whether a {@code Link} is active
 * 
 * @author Matthew Swartwout
 *
 */
public enum Activity 
{
	ACTIVE,
	INACTIVE;
}
