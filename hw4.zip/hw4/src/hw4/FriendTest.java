package hw4;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FriendTest 
{
	@Before
	public void testSetup() throws NullPointerException, UninitializedObjectException
	{
		SocialNetwork network = new SocialNetwork();
		
		User user1 = new User();
		User user2 = new User();
		User user3 = new User();
		
		user1.setID("User1");
		user2.setID("User2");
		user3.setID("User3");
		
		network.addUser(user1);
		network.addUser(user2);
		network.addUser(user3);
	}
	
	public void testNeighborhood()
	{
		Friend user1FriendUser2 = new Friend();
		user1FriendUser2.set(user2, 5);
		user1.addFriend(user1FriendUser2);
	}
}
