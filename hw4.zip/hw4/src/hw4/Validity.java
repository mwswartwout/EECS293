package hw4;

/**
 * Enum {@code Validity} represents whether a user is valid or invalid
 * 
 * @author Matthew Swartwout
 *
 */
public enum Validity 
{
	VALID,
	INVALID;
}
