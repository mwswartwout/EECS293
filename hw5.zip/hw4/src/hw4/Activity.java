package hw4;

/**
 * Marks whether a {@code Link} is active
 * 
 * @author Matthew Swartwout
 *
 */
public enum Activity 
{
	ACTIVE,
	INACTIVE;
}
