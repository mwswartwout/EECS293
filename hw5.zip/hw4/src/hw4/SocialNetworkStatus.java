package hw4;

public class SocialNetworkStatus 
{	
	private Status status;
	
	public SocialNetworkStatus(Status status)
	{
		this.status = status;
	}
	
	public void setStatus(Status status)
	{
		this.status = status;
	}
	
	public Status getStatus()
	{
		return status;
	}
}
